$( function() {
    $( "#accordion" ).accordion({
      collapsible: true
    });
  } );